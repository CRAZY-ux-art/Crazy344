// قائمة الملفات التي تريد عرضها
const files = [
  { name: "تحميل ملفات انوي 🌟 6", path: "files/inwi6.zip" },
  { name: "تحميل ملفات اتصالات 🌟 6", path: "files/etisalat6.zip" }
];

// عرض الملفات في الصفحة
const list = document.getElementById("file-list");

files.forEach(file => {
  const li = document.createElement("li");
  const a = document.createElement("a");
  a.href = file.path;
  a.textContent = file.name;
  a.download = file.path.split("/").pop(); // التحميل المباشر
  li.appendChild(a);
  list.appendChild(li);
});
